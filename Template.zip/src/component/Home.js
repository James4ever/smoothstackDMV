"use strict"
import React from 'react';

export const Home = () => {
    return (
        <div className="jumbotron">
            <h1>Welcome to TC-DMV</h1>
        </div>
    );
}